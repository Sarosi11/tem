from django.contrib import admin
from .models import Login,Signup
# Register your models here.
admin.site.register(Login)
admin.site.register(Signup)