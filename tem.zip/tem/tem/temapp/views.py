from django.shortcuts import render,redirect,reverse
from.models import Login,Signup
from datetime import date
from django.contrib import messages
# Create your views here.
def index(request):
    return render(request,"index.html")
def login(request):
    if request.method=="POST":
        userid=request.POST['userid']
        password=request.POST['password']
        usertype=request.POST['usertype']
        try:
            obj=Login.objects.get(userid=userid,password=password)
            if obj.usertype=="user":
                #messages.success(request,'Welcome ff')
                request.session['userid']=userid #session variable create kiya jiski id roll no hai
                return redirect(reverse('user:userhome'))
            elif obj.usertype=="admin":
                #messages.success(request,'Welcome Admin')
                request.session['adminid']=userid
                return redirect(reverse('adminapp:adminhome'))
            elif obj.usertype=="vendor":
                #messages.success(request,'Welcome vendor')
                request.session['vendorid']=userid
                return redirect(reverse('vendor:vendorhome'))            
        except:
            messages.success(request,'Invalid User')
    return render(request,"login.html",locals())
def registration(request):
    if request.method=="POST":
        userid=request.POST['userid']
        name=request.POST['name']
        fname=request.POST['fname']
        mname=request.POST['mname']
        gender=request.POST['gender']
        contactno=request.POST['contactno']
        emailaddress=request.POST['emailaddress']
        password=request.POST['password']
        regdate=date.today()
        usertype='student'
        status='false'
        # ---------------------------------------orm - object realtionship method [next two is meaning]---------------------------------------------------------------------
        re=Signup(userid=userid,name=name,fname=fname,mname=mname,gender=gender,contactno=contactno,emailaddress=emailaddress,regdate=regdate)
        log=Login(userid=userid,password=password,usertype=usertype,status=status)
        re.save()
        log.save()
        msg=f'Hello,{name}Your Registration Is Successfull. Your Password is {password}'
        messages.success(request,"Registration Successful ")
    return render(request,"registration.html",locals())