from django.shortcuts import render

# Create your views here.
def adminapphome(request):
    return render(request,"adminapphome.html")